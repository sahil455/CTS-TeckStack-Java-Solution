//package arrayManipulation;

import java.util.InputMismatchException;
import java.util.Scanner;


public class ArrayException {

	public static void main(String[] args) {
		ArrayException ax=new ArrayException();
		String result= ax.getPriceDetails();	
		System.out.println(result);
 }
	public String getPriceDetails() 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of elements in the array");
		int n=sc.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the price details");
		for(int i=0;i<n;i++)
		{
			try {
			a[i]=sc.nextInt();
             }
	        catch (InputMismatchException e) {
		        return ("Input was not in the correct format");
        	} 
		}
		int index=0;
	    System.out.println("Enter the index of the array element you want to access");
	    index=sc.nextInt();
	    try {
	    	if(index >(n-1)) 
	    	{
	    			 throw new ArrayIndexOutOfBoundsException("Array index is out of range");
	    	}
	    }
		    
		catch (ArrayIndexOutOfBoundsException e) {
			return e.getMessage();
		}
	    
		
		return ("The array element is "+a[index]);
	}
}

