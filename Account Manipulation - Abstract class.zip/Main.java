import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner sc=new Scanner(System.in);
        int customerId=sc.nextInt();
        String customerName=sc.next();
        String emailId=sc.next();
        Customer customerObj = new Customer(customerId, customerName, emailId);
        int accountNumber=sc.nextInt();
        double balance=sc.nextDouble();
        double minimumBalance=sc.nextDouble();
		SavingsAccount savingAccount=new SavingsAccount(accountNumber, customerObj, balance, minimumBalance);
        double amount = sc.nextDouble();
		boolean b=savingAccount.withdraw(amount);
		
		
	}

}