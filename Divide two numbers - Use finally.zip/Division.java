import java.util.Scanner;

public class Division {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Division d=new Division();
		System.out.println("Enter the numbers");
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		String result=d.divideTwoNumbers(num1,num2);
	}
	public String divideTwoNumbers(int number1,int number2) {
		try {
			int result=number1/number2;
			return ("The answer is "+result+". Thanks for using the application.");
		}catch (ArithmeticException e) {
			// TODO: handle exception
			return ("Division by zero is not possible.Thanks for using the application.");
		}	
	}

}