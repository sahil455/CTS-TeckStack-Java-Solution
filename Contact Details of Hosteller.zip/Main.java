//package contactdetailsofhostlers;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.Buffer;
import java.util.Scanner;

public class Main {

	static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		Hosteller s=new Hosteller();
		System.out.println("Enter the Details:");
		InputStreamReader r=new InputStreamReader(System.in);    
	    BufferedReader br=new BufferedReader(r);        
		System.out.println("Student Id");
		s.setStudentId(sc.nextInt());
		System.out.println("Student Name");
		s.setName(br.readLine());
		System.out.println("Department Id");
		s.setDepartmentId(sc.nextInt());
		System.out.println("Gender");
		s.setGender(sc.next());
		System.out.println("Phone Number");
		s.setPhone(sc.next());
		System.out.println("Hostel Name");
		s.setHostelName(sc.next());
		System.out.println("Room Number");
		s.setRoomNumber(sc.nextInt());
		s=getHostellerDetails();
		System.out.println("The Student Details:");
		System.out.print(s.getStudentId()+" "+s.getName()+" "+s.getDepartmentId()+" "+s.getGender()+" "+s.getPhone()+" "+s.getHostelName()+" "+s.getRoomNumber());
		

	}
	public static Hosteller getHostellerDetails() {
	    	Hosteller s=new Hosteller();
		System.out.println("Modify Room Number(Y/N)");
		char option1=sc.next().charAt(0);
		if(option1=='Y') {
			System.out.println("New Room Number");
			s.setRoomNumber(sc.nextInt());
		}
		System.out.println("Modify Phone Number(Y/N)");
		char option2=sc.next().charAt(0);
		if(option2=='Y') {
			System.out.println("New Phone Number");
			s.setPhone(sc.next());
		}	
		return s;
	}



}
