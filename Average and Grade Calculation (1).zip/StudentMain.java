import java.util.*;
public class StudentMain
{
    public static Student getStudentDetails()
    {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter the id:");
        int id=scan.nextInt();
        System.out.println("Enter the name:");
        String name=scan.next();
        System.out.println("Enter the no of subjects:");
        int noOfSubjects=scan.nextInt();
        
        while(!(noOfSubjects>0))
        {
            System.out.println("Invalid number of subject");
            System.out.println("Enter the no of subjects:");
            noOfSubjects=scan.nextInt();
        }
        int[] marks=new int[noOfSubjects];
        
        for(int i=0;i<noOfSubjects;i++)
        {
            System.out.println("Enter mark for subject "+(i+1));
            marks[i]=scan.nextInt();
            
            while(!(marks[i]>=0 && marks[i]<=100))
            {
                System.out.println("Invalid Mark");
                System.out.println("Enter mark for subject "+(i+1));
                marks[i]=scan.nextInt();
            }
        }
        return new Student(id,name,marks);
    }
    public static void main (String[] args) 
    {
        Scanner scan=new Scanner(System.in);
        Student s=getStudentDetails();
        s.calculateAvg();
        s.findGrade();
        System.out.println("Id:"+s.getId());
        System.out.println("Name:"+s.getName());
        System.out.println("Average:"+s.getAverage());
        System.out.println("Grade:"+s.getGrade());
        
    }
}