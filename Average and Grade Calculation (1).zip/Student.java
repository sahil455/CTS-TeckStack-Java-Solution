public class Student
{
    private int id;
    private String name; 
    private int[] marks;
    private float average;
    private char grade;
    
    public Student(int id,String name,int[] marks)
    {
        this.id=id;
        this.name=name;
        this.marks=marks;
    }
    
    public int getId()
    {   return id;  }
    public String getName()
    {   return name;    }
    public int[] getMarks()
    {   return marks;   }
    public float getAverage()
    {   return average; }
    public char getGrade()
    {   return grade;   }
    
    public void setId(int id)
    {   this.id=id;}
    public void setName(String name)
    {   this.name=name; }
    public void setMarks(int[] marks)
    {   this.marks=marks;}
    public void setAverage(float avg)
    {   average=avg;}
    public void setGrade(char grade)
    {   this.grade=grade;   }
    
    public void calculateAvg()
    {
        int total=0;
        for(int i=0;i<marks.length;i++)
        {
            total+=marks[i];
        }
        average=(float) total/marks.length;
    }
    
    public void findGrade()
    {
        for(int x:marks)
        {
            if(x<50)
            {
                grade='F';
                return;
            }    
        }
        if(average>=80&&average<=100)
        {
            grade='O';
        }
        else
        {
            grade='A';
        }
    }
}