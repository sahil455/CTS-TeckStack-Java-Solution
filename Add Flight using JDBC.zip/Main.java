import java.util.*;
import java.sql.SQLException;

public class Main{
    public static void main(String[] args) throws SQLException{
        Scanner sc=new Scanner(System.in);
      
        int flightId=sc.nextInt();
        String source=sc.next();
        String destination=sc.next();
        int noOfseats=sc.nextInt();
        double flightFare=sc.nextDouble();
        
        Flight flightObj=new Flight(flightId,source,destination,noOfseats,flightFare);
        
        FlightManagementSystem fm=new FlightManagementSystem();
        boolean b=fm.addFlight(flightObj);
        if(b==true)
            System.out.println("Flight details added successfully");
        else 
            System.out.println("Additon not done.");
        
    }
}