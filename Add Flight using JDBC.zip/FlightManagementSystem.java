import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
 public class FlightManagementSystem
 {
    public boolean addFlight(Flight flightObj) 
    
    {
        int rowCount=0;
        Connection con=null;
        try 
        {
            try{
            con=DB.getConnection();
            }catch(Exception e){}
            PreparedStatement pst=con.prepareStatement("insert into Flight values (?,?,?,?,?)");
            pst.setInt(1,flightObj.getFlightId());
            pst.setString(2,flightObj.getSource());
            pst.setString(3,flightObj.getDestination());
            pst.setInt(4,flightObj.getNoOfSeats());
            pst.setDouble(5,flightObj.getFlightFare());
            rowCount=pst.executeUpdate();
        }
        catch(SQLException se){}
            if(rowCount==1)
                  return true;
             else 
                  return false;
        
    //con.close();
    }
 }